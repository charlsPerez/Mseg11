﻿using mseg11.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mseg11.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public string GuardarAlmno(string Txt_NombreAlumno, int Txt_IdAlumno)
        {
            using (CenfotecEntities BD = new CenfotecEntities())
            {
                try
                {
                    Alumno Registro = new Alumno()
                    {
                        ID = Txt_IdAlumno,
                        NomAlumno = Txt_NombreAlumno
                    };

                    BD.Alumno.Add(Registro);
                    BD.SaveChanges();
                    return "true";
                }
                catch (Exception Error)
                {
                    return "False";
                }
            }
        }

        public ActionResult traerInfo()
        {
            return View();
        }
    }
}