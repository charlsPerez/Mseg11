﻿using mseg11.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mseg11.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public string GuardarAlmno(string Txt_NombreAlumno, int Txt_IdAlumno)
        {
            using (CenfotecEntities BD = new CenfotecEntities())
            {
                try
                {
                    Alumno Registro = new Alumno()
                    {
                        ID = Txt_IdAlumno,
                        NomAlumno = Txt_NombreAlumno
                    };

                    BD.Alumno.Add(Registro);
                    BD.SaveChanges();
                    return "true";
                }
                catch (Exception Error)
                {
                    return "False";
                }
            }
        }

        public ActionResult MostrarAlumno(int Txt_IdAlumnoConsulta)
        {
            /*
            CenfotecEntities basedatos = new CenfotecEntities();
            Alumno alumnoencontrado = basedatos.Alumno.Where(x=>x.ID== Txt_IdAlumnoConsulta).First();
            return View(alumnoencontrado);
             */
            CenfotecEntities basedatos = new CenfotecEntities();
            Alumno alumnoencontrado = new Alumno();

            try
            {
                
                alumnoencontrado = basedatos.Alumno.Where(x => x.ID == Txt_IdAlumnoConsulta).First();
            }
            catch (Exception e)
            {
                alumnoencontrado = new Alumno()
                {
                    ID = 0, NomAlumno = "No encontrado"
                };

            }
            return View(alumnoencontrado);

        }
    }
}