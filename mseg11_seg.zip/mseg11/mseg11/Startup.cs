﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(mseg11.Startup))]
namespace mseg11
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
